angular.module('imdbApp').
component('headerapp', {
    templateUrl: "./header/header.template.html",
    // styleUrls: ['./header/header.css'],
    controller: function headerController() {
        this.myname = "header";
        this.inputValue;

        this.getImdbSearchValue = function() {
                // this.searchdata = { "$": this.inputValue };
                this.searchdata = { "$": this.inputValue };
            }
            // this.getFilterKey = function(e) {
            //         this.selectedKey = e.target.getAttribute("value");
            //         console.log(this.selectedKey);
            //         e.target.setAttribute("ng-selected", "selected");
            //         document.getElementById("selectbox").querySelectorAll("#imdbInputSearch .input-group .dropdown-item").forEach((element) => { element.removeAttribute("ng-selected") })
            //     }
            // document.getElementById("selectbox").addEventListener("click", function(event) {
            //     console.log(event.target.getAttribute("value"));
            // });
    },
    bindings: {
        searchdata: `=`

    }
});